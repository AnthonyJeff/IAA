Os códigos em C foram compilados com o compilador GCC (GNU Compiler Collection).
