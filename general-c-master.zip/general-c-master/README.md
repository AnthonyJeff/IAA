# General C

### Português
Basicamente, esse repo tem como objetivo disponibilizar os arquivos / programas em C feitos em algumas cadeiras da faculdade, além de códigos aleatórios que porventura eu possa ter feito.

### English
This repo was made to host my C files / programs written while I was taking some university courses, besides random code I wrote for whatever reason.
